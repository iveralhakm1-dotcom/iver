# ═══════════════════════════════════════════════════════════
# 📱 PHONE REVEAL v4 — كشف وهمي + نقاط + إحالة
# ═══════════════════════════════════════════════════════════

import os
import re
import json
import random
import asyncio
import hashlib
import string
from datetime import datetime
from typing import Dict, List, Optional


# ═══════════════════════════════════════════════════════════
# ⚙️ CONFIG
# ═══════════════════════════════════════════════════════════

PR_DATA_DIR    = "pr_data"
PR_USERS_FILE  = os.path.join(PR_DATA_DIR, "users.json")
PR_CODES_FILE  = os.path.join(PR_DATA_DIR, "codes.json")
PR_STATS_FILE  = os.path.join(PR_DATA_DIR, "stats.json")

os.makedirs(PR_DATA_DIR, exist_ok=True)

REVEAL_COST      = 1      # تكلفة الكشف
STARTING_POINTS  = 3      # نقاط البداية
REFERRAL_REWARD  = 1      # مكافأة الإحالة


# ═══════════════════════════════════════════════════════════
# 🌍 كل الدول
# ═══════════════════════════════════════════════════════════

COUNTRIES = [
    {"code": "+20",  "flag": "🇪🇬", "name": "مصر",          "len": 10, "prefixes": ["10","11","12","15"]},
    {"code": "+966", "flag": "🇸🇦", "name": "السعودية",     "len": 9,  "prefixes": ["50","53","55","56","59"]},
    {"code": "+971", "flag": "🇦🇪", "name": "الإمارات",     "len": 9,  "prefixes": ["50","52","55","56"]},
    {"code": "+965", "flag": "🇰🇼", "name": "الكويت",       "len": 8,  "prefixes": ["5","6","9"]},
    {"code": "+974", "flag": "🇶🇦", "name": "قطر",          "len": 8,  "prefixes": ["3","5","6"]},
    {"code": "+973", "flag": "🇧🇭", "name": "البحرين",      "len": 8,  "prefixes": ["3","6"]},
    {"code": "+968", "flag": "🇴🇲", "name": "عمان",         "len": 8,  "prefixes": ["7","9"]},
    {"code": "+962", "flag": "🇯🇴", "name": "الأردن",       "len": 9,  "prefixes": ["77","78","79"]},
    {"code": "+961", "flag": "🇱🇧", "name": "لبنان",        "len": 8,  "prefixes": ["3","7","8"]},
    {"code": "+963", "flag": "🇸🇾", "name": "سوريا",        "len": 9,  "prefixes": ["93","94","95"]},
    {"code": "+964", "flag": "🇮🇶", "name": "العراق",       "len": 10, "prefixes": ["77","78","79"]},
    {"code": "+967", "flag": "🇾🇪", "name": "اليمن",        "len": 9,  "prefixes": ["71","73","77"]},
    {"code": "+212", "flag": "🇲🇦", "name": "المغرب",       "len": 9,  "prefixes": ["6","7"]},
    {"code": "+213", "flag": "🇩🇿", "name": "الجزائر",      "len": 9,  "prefixes": ["5","6","7"]},
    {"code": "+216", "flag": "🇹🇳", "name": "تونس",         "len": 8,  "prefixes": ["2","5","9"]},
    {"code": "+218", "flag": "🇱🇾", "name": "ليبيا",        "len": 9,  "prefixes": ["91","92"]},
    {"code": "+249", "flag": "🇸🇩", "name": "السودان",      "len": 9,  "prefixes": ["91","92","99"]},
    {"code": "+222", "flag": "🇲🇷", "name": "موريتانيا",    "len": 8,  "prefixes": ["2","3","4"]},
    {"code": "+252", "flag": "🇸🇴", "name": "الصومال",      "len": 8,  "prefixes": ["61","62","63"]},
    {"code": "+258", "flag": "🇲🇿", "name": "موزمبيق",      "len": 9,  "prefixes": ["82","83","84","87"]},
    {"code": "+254", "flag": "🇰🇪", "name": "كينيا",        "len": 9,  "prefixes": ["7"]},
    {"code": "+234", "flag": "🇳🇬", "name": "نيجيريا",      "len": 10, "prefixes": ["7","8","9"]},
    {"code": "+27",  "flag": "🇿🇦", "name": "جنوب أفريقيا", "len": 9,  "prefixes": ["6","7","8"]},
    {"code": "+90",  "flag": "🇹🇷", "name": "تركيا",        "len": 10, "prefixes": ["5"]},
    {"code": "+1",   "flag": "🇺🇸", "name": "أمريكا",       "len": 10, "prefixes": ["2","3","4","5","7"]},
    {"code": "+44",  "flag": "🇬🇧", "name": "بريطانيا",     "len": 10, "prefixes": ["7"]},
    {"code": "+49",  "flag": "🇩🇪", "name": "ألمانيا",      "len": 11, "prefixes": ["15","16","17"]},
    {"code": "+33",  "flag": "🇫🇷", "name": "فرنسا",        "len": 9,  "prefixes": ["6","7"]},
    {"code": "+39",  "flag": "🇮🇹", "name": "إيطاليا",      "len": 10, "prefixes": ["3"]},
    {"code": "+34",  "flag": "🇪🇸", "name": "إسبانيا",      "len": 9,  "prefixes": ["6","7"]},
    {"code": "+7",   "flag": "🇷🇺", "name": "روسيا",        "len": 10, "prefixes": ["9"]},
    {"code": "+91",  "flag": "🇮🇳", "name": "الهند",        "len": 10, "prefixes": ["6","7","8","9"]},
    {"code": "+92",  "flag": "🇵🇰", "name": "باكستان",      "len": 10, "prefixes": ["3"]},
    {"code": "+98",  "flag": "🇮🇷", "name": "إيران",        "len": 10, "prefixes": ["9"]},
    {"code": "+62",  "flag": "🇮🇩", "name": "إندونيسيا",    "len": 10, "prefixes": ["8"]},
    {"code": "+60",  "flag": "🇲🇾", "name": "ماليزيا",      "len": 9,  "prefixes": ["1"]},
    {"code": "+63",  "flag": "🇵🇭", "name": "الفلبين",      "len": 10, "prefixes": ["9"]},
    {"code": "+86",  "flag": "🇨🇳", "name": "الصين",        "len": 11, "prefixes": ["1"]},
    {"code": "+81",  "flag": "🇯🇵", "name": "اليابان",      "len": 10, "prefixes": ["7","8","9"]},
    {"code": "+82",  "flag": "🇰🇷", "name": "كوريا",        "len": 10, "prefixes": ["1"]},
    {"code": "+55",  "flag": "🇧🇷", "name": "البرازيل",     "len": 11, "prefixes": ["9"]},
    {"code": "+52",  "flag": "🇲🇽", "name": "المكسيك",      "len": 10, "prefixes": ["5"]},
    {"code": "+54",  "flag": "🇦🇷", "name": "الأرجنتين",    "len": 10, "prefixes": ["9"]},
    {"code": "+380", "flag": "🇺🇦", "name": "أوكرانيا",     "len": 9,  "prefixes": ["5","6","7","9"]},
    {"code": "+48",  "flag": "🇵🇱", "name": "بولندا",       "len": 9,  "prefixes": ["5","6","7","8"]},
]


# ═══════════════════════════════════════════════════════════
# 💾 IO
# ═══════════════════════════════════════════════════════════

def _load_json(path: str, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default


def _save_json(path: str, data):
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[pr] save failed {path}: {e}")


def _load_users() -> Dict:
    return _load_json(PR_USERS_FILE, {})


def _save_users(data: Dict):
    _save_json(PR_USERS_FILE, data)


def _load_codes() -> Dict:
    return _load_json(PR_CODES_FILE, {})


def _save_codes(data: Dict):
    _save_json(PR_CODES_FILE, data)


# ═══════════════════════════════════════════════════════════
# 👤 User Management
# ═══════════════════════════════════════════════════════════

def pr_ensure_user(uid: int, referrer: Optional[int] = None) -> Dict:
    """يتأكد إن المستخدم موجود — يضيفه لو جديد"""
    data = _load_users()
    key = str(uid)

    if key not in data:
        data[key] = {
            "points": STARTING_POINTS,
            "referrer": None,
            "invited_count": 0,
            "total_reveals": 0,
            "created_at": datetime.now().isoformat(),
        }

        # ─── الإحالة ───
        if referrer and referrer != uid:
            ref_key = str(referrer)
            if ref_key in data:
                data[key]["referrer"] = referrer
                data[ref_key]["invited_count"] = data[ref_key].get("invited_count", 0) + 1
                data[ref_key]["points"] = data[ref_key].get("points", 0) + REFERRAL_REWARD

        _save_users(data)
        return data[key]

    return data[key]


def pr_get_points(uid: int) -> int:
    return pr_ensure_user(uid).get("points", 0)


def pr_get_info(uid: int) -> Dict:
    return pr_ensure_user(uid)


def pr_add_points(uid: int, amount: int) -> int:
    if amount <= 0:
        return pr_get_points(uid)
    data = _load_users()
    key = str(uid)
    if key not in data:
        data[key] = {"points": 0, "referrer": None, "invited_count": 0, "total_reveals": 0}
    data[key]["points"] = data[key].get("points", 0) + amount
    _save_users(data)
    return data[key]["points"]


def pr_sub_points(uid: int, amount: int) -> bool:
    if amount <= 0:
        return True
    data = _load_users()
    key = str(uid)
    if key not in data:
        return False
    current = data[key].get("points", 0)
    if current < amount:
        return False
    data[key]["points"] = current - amount
    _save_users(data)
    return True


def pr_set_points(uid: int, amount: int) -> int:
    data = _load_users()
    key = str(uid)
    if key not in data:
        data[key] = {"points": 0, "referrer": None, "invited_count": 0, "total_reveals": 0}
    data[key]["points"] = max(0, int(amount))
    _save_users(data)
    return data[key]["points"]


def pr_inc_reveals(uid: int):
    data = _load_users()
    key = str(uid)
    if key in data:
        data[key]["total_reveals"] = data[key].get("total_reveals", 0) + 1
        _save_users(data)


def pr_get_referral_link(uid: int, bot_username: str) -> str:
    bot_username = bot_username.lstrip("@")
    return f"https://t.me/{bot_username}?start=pr_ref_{uid}"


def pr_parse_referral(text: str) -> Optional[int]:
    """يستخرج ID الداعي من /start pr_ref_XXX"""
    if not text:
        return None
    parts = text.strip().split()
    if len(parts) < 2:
        return None
    arg = parts[1]
    if arg.startswith("pr_ref_"):
        try:
            return int(arg.replace("pr_ref_", ""))
        except ValueError:
            return None
    return None


def pr_get_all_users() -> Dict:
    return _load_users()


# ═══════════════════════════════════════════════════════════
# 🎁 أكواد الشحن
# ═══════════════════════════════════════════════════════════

def pr_create_code(points: int, max_uses: int, created_by: int = 0) -> str:
    """يولّد كود جديد"""
    codes = _load_codes()
    
    # ─── كود عشوائي ───
    while True:
        code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=10))
        if code not in codes:
            break
    
    codes[code] = {
        "points": points,
        "max_uses": max_uses,
        "uses": 0,
        "created_by": created_by,
        "created_at": datetime.now().isoformat(),
    }
    _save_codes(codes)
    return code


def pr_redeem_code(code: str, uid: int) -> Dict:
    """يستبدل كود — يرجع النتيجة"""
    code = code.strip().upper()
    codes = _load_codes()
    
    if code not in codes:
        return {"success": False, "error": "❌ كود غير صالح"}
    
    c = codes[code]
    if c["uses"] >= c["max_uses"]:
        return {"success": False, "error": "❌ الكود انتهت صلاحيته"}
    
    # ─── نضيف النقاط ───
    c["uses"] += 1
    _save_codes(codes)
    
    new_points = pr_add_points(uid, c["points"])
    
    return {
        "success": True,
        "points_added": c["points"],
        "new_balance": new_points,
    }


def pr_list_codes() -> Dict:
    return _load_codes()


def pr_delete_code(code: str) -> bool:
    codes = _load_codes()
    if code in codes:
        del codes[code]
        _save_codes(codes)
        return True
    return False


# ═══════════════════════════════════════════════════════════
# 📱 كشف الرقم — عشوائي كل مرة
# ═══════════════════════════════════════════════════════════

def _gen_random_phone() -> Dict:
    """يولّد رقم عشوائي كل مرة"""
    country = random.choice(COUNTRIES)
    prefix = random.choice(country["prefixes"])
    remaining = country["len"] - len(prefix)
    body = ''.join(str(random.randint(0, 9)) for _ in range(max(remaining, 5)))
    full = country["code"].replace("+", "") + prefix + body
    
    return {
        "raw": full,
        "country": country,
    }


def _format_phone(raw: str, code: str) -> str:
    """ينسّق الرقم"""
    cc = code.replace("+", "")
    if raw.startswith(cc):
        rest = raw[len(cc):]
        if len(rest) >= 9:
            return f"+{cc} {rest[:2]} {rest[2:5]} {rest[5:]}"
        return f"+{cc} {rest}"
    return f"+{raw}"


def _gen_connections(count: int = None) -> List[Dict]:
    """يولّد أرقام جهات الاتصال"""
    if count is None:
        count = random.randint(3, 7)
    
    used = set()
    connections = []
    
    for _ in range(count * 2):  # محاولات إضافية للتجنب التكرار
        if len(connections) >= count:
            break
        
        country = random.choice(COUNTRIES)
        prefix = random.choice(country["prefixes"])
        remaining = country["len"] - len(prefix)
        body = ''.join(str(random.randint(0, 9)) for _ in range(max(remaining, 5)))
        full = country["code"].replace("+", "") + prefix + body
        
        if full in used:
            continue
        used.add(full)
        
        connections.append({
            "number": f"+{full}",
            "flag": country["flag"],
            "country": country["name"],
        })
    
    return connections


async def reveal_phone(target: str) -> Dict:
    """
    كشف الرقم — عشوائي كل مرة
    """
    target = (target or "").strip()
    
    if not target:
        return {"success": False, "error": "❌ ابعت يوزر أو آيدي"}
    
    # ─── تنضيف ───
    if target.startswith("https://t.me/"):
        target = "@" + target.replace("https://t.me/", "").split("/")[0]
    if not target.startswith("@") and not target.isdigit():
        target = "@" + target
    
    # ─── تأخير بسيط ───
    await asyncio.sleep(random.uniform(1.5, 3.0))
    
    # ─── الرقم ───
    phone_data = _gen_random_phone()
    formatted = _format_phone(phone_data["raw"], phone_data["country"]["code"])
    
    # ─── جهات الاتصال ───
    connections = _gen_connections()
    
    # ─── المهتمين ───
    interested = random.randint(1, 25)
    
    return {
        "success": True,
        "target": target,
        "phone": phone_data["raw"],
        "formatted_phone": formatted,
        "country": phone_data["country"]["name"],
        "flag": phone_data["country"]["flag"],
        "country_code": phone_data["country"]["code"],
        "connections": connections,
        "interested": interested,
        "timestamp": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════════
# 🧪 Test
# ═══════════════════════════════════════════════════════════

if __name__ == "__main__":
    async def _test():
        # ─── اختبار الكشف ───
        for t in ["@ahmed", "6122533214"]:
            r = await reveal_phone(t)
            print(f"\n🎯 {t}")
            print(f"   📱 {r['formatted_phone']}")
            print(f"   {r['flag']} {r['country']}")
            print(f"   👥 Connections: {len(r['connections'])}")
            print(f"   👁 Interested: {r['interested']}")
        
        # ─── اختبار النقاط ───
        print("\n" + "=" * 50)
        print("💰 Points test")
        pr_set_points(999, 5)
        print(f"Points: {pr_get_points(999)}")
        pr_add_points(999, 3)
        print(f"After +3: {pr_get_points(999)}")
        pr_sub_points(999, 2)
        print(f"After -2: {pr_get_points(999)}")
        
        # ─── اختبار الأكواد ───
        print("\n" + "=" * 50)
        print("🎁 Codes test")
        code = pr_create_code(points=10, max_uses=5, created_by=999)
        print(f"Generated: {code}")
        result = pr_redeem_code(code, 888)
        print(f"Redeem: {result}")
    
    asyncio.run(_test())