#!/usr/bin/env python3
#غير مسوول عن اي ستخدام خاطا
#غير مسوول عن اي تعديل داخل الادات
#غير مبري الذمه عند تعديل الادات
"""
t4c.py — Python File Protector (CLI Mode)
Usage: python t4c.py <mode> <method> <input> <output>
   mode: enc | dec
   method: base64 | marshal | zlib | lzma | gzip | bz2
"""
import sys
import os
import json
import base64
import marshal
import zlib
import lzma
import gzip
import bz2

SIGNATURE = "# تم {} ملف بواسطة @rxuxv\n".format

def wrap_code(encoded_data, method):
    sig = SIGNATURE("تشفير").encode()
    if method == 'base64':
        return sig + f"import base64\nexec(base64.b64decode({encoded_data}))".encode()
    if method == 'marshal':
        return sig + f"import marshal\nexec(marshal.loads({encoded_data}))".encode()
    if method == 'zlib':
        return sig + f"import zlib\nexec(zlib.decompress({encoded_data}))".encode()
    if method == 'lzma':
        return sig + f"import lzma\nexec(lzma.decompress({encoded_data}))".encode()
    if method == 'gzip':
        return sig + f"import gzip\nexec(gzip.decompress({encoded_data}))".encode()
    if method == 'bz2':
        return sig + f"import bz2\nexec(bz2.decompress({encoded_data}))".encode()
    return None


def process(input_path, output_path, method, mode):
    """mode = 'enc' أو 'dec'"""
    try:
        with open(input_path, "rb") as f:
            file_data = f.read()

        if mode == "enc":
            if method == 'base64':
                raw = base64.b64encode(file_data)
            elif method == 'marshal':
                compiled = compile(file_data.decode('utf-8'), '<string>', 'exec')
                raw = marshal.dumps(compiled)
            elif method == 'zlib':
                raw = zlib.compress(file_data)
            elif method == 'lzma':
                raw = lzma.compress(file_data)
            elif method == 'gzip':
                raw = gzip.compress(file_data)
            elif method == 'bz2':
                raw = bz2.compress(file_data)
            else:
                return {"success": False, "error": f"unknown method: {method}"}
            final_data = wrap_code(repr(raw), method)
        else:
            if method == 'base64':
                decoded = base64.b64decode(file_data)
            elif method == 'marshal':
                decoded = str(marshal.loads(file_data)).encode()
            elif method == 'zlib':
                decoded = zlib.decompress(file_data)
            elif method == 'lzma':
                decoded = lzma.decompress(file_data)
            elif method == 'gzip':
                decoded = gzip.decompress(file_data)
            elif method == 'bz2':
                decoded = bz2.decompress(file_data)
            else:
                return {"success": False, "error": f"unknown method: {method}"}
            final_data = SIGNATURE("فك تشفير").encode() + decoded

        with open(output_path, "wb") as f:
            f.write(final_data)

        return {
            "success": True,
            "output": output_path,
            "size": len(final_data),
            "mode": mode,
            "method": method,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


if __name__ == "__main__":
    if len(sys.argv) != 5:
        print(json.dumps({
            "success": False,
            "error": "Usage: t4c.py <mode> <method> <input> <output>"
        }))
        sys.exit(1)

    mode, method, inp, out = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
    result = process(inp, out, method, mode)
    print(json.dumps(result))