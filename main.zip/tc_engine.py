# ═══════════════════════════════════════════════════════════
# 📞 TC ENGINE v4 — Truecaller واقعي (Variations)
# ═══════════════════════════════════════════════════════════

import os, re, json, random, asyncio, string
from datetime import datetime
from typing import Dict, List, Optional


TC_DATA_DIR   = "tc_data"
TC_USERS_FILE = os.path.join(TC_DATA_DIR, "users.json")
TC_CODES_FILE = os.path.join(TC_DATA_DIR, "codes.json")
os.makedirs(TC_DATA_DIR, exist_ok=True)

STARTING_POINTS = 3
REVEAL_COST     = 1
REFERRAL_REWARD = 1


# ═══════════════════════════════════════════════════════════
# 📚 DATABASE — أسماء مصرية كبيرة
# ═══════════════════════════════════════════════════════════

FIRST_NAMES_AR = [
    "أحمد","محمد","محمود","مصطفى","عمر","يوسف","علي","حسن","إبراهيم","خالد",
    "أيمن","عمرو","طارق","هشام","كريم","سامح","شريف","ياسر","وائل","أشرف",
    "إسلام","رضا","ماجد","هاني","نادر","سيد","رمضان","صلاح","فتحي","عبدالله",
    "حسام","سامي","بهاء","نبيل","طلعت","عادل","مجدي","سعيد","جميل","لطفي",
    "عاطف","صبري","شعبان","فارس","ثروت","زكي","أنور","جمال","رفعت","سمير",
    "عصام","عصمت","مدحت","منير","نعمان","مسعد","مروان","زياد","باسم","بدر",
    "رامي","ريمون","سعد","سمير","شادي","شاكر","صابر","صفوت","ضياء","طه",
    "عابد","عبدالعزيز","عبدالرحمن","عثمان","عرفة","عفت","علاء","عماد","غريب","فؤاد",
    "فاضل","فتحي","قاسم","كمال","لبيب","ماهر","محمود","مسعود","مصطفى","معتز",
    "منصور","ناجي","نصر","نور","هاشم","وجدي","وليد","يحيى","يقين","يونس",
    "إياد","مينا","كيرلس","جرجس","مجدى","رؤوف","رمزي","صفوت","عادل","فتحي",
]

FIRST_NAMES_EN = [
    "Ahmed","Mohamed","Mahmoud","Mostafa","Omar","Youssef","Ali","Hassan",
    "Ibrahim","Khaled","Ayman","Amr","Tarek","Hesham","Karim","Sameh","Sherif",
    "Yasser","Wael","Ashraf","Islam","Reda","Maged","Hany","Nader","Sayed",
    "Ramadan","Salah","Fathy","Abdullah","Hossam","Samy","Bahaa","Nabil",
    "Talaat","Adel","Magdy","Saeed","Gamal","Lotfy","Atef","Sabry","Shaban",
    "Fares","Tharwat","Zaki","Anwar","Gamal","Refaat","Samir","Essam","Medhat",
    "Mounir","Noman","Mossaad","Marwan","Ziad","Bassem","Badr","Ramy","Raymond",
    "Saad","Shady","Shaker","Saber","Safwat","Diaa","Taha","Abed","Abdelaziz",
    "Abdelrahman","Osman","Arafa","Afaf","Alaa","Emad","Gharib","Fouad","Fadel",
    "Qassem","Kamal","Labib","Maher","Massoud","Motaz","Mansour","Nagi","Nasr",
    "Nour","Hashem","Wagdy","Walid","Yehia","Younes","Eyad","Mina","Kyrillos",
]

LAST_NAMES_AR = [
    "محمد","أحمد","علي","إبراهيم","حسن","حسين","سعيد","فؤاد","كامل","رأفت",
    "السيد","الشناوي","عبدالله","عبدالرحمن","العشري","الفقي","مرسي","سليمان",
    "الألفي","البنا","المكاوي","عوف","عاطف","حمزة","سعودي","بدر","كيلاني",
    "ممدوح","الكهربائي","الحلاق","الجزار","الخولي","الششتاوي","عرفة","عابد",
    "زايد","طلعت","صقر","نجم","غانم","سلامة","كمال","منصور","شلبي","شلبي",
    "الشامي","الحلواني","الشرقاوي","البدري","السقا","العدل","التركي","الباز",
    "الأشقر","الطويل","القصير","الطنطاوي","الدسوقي","المنشاوي","الفيومي",
    "البحيري","الصعيدي","القناوي","الأسيوطي","درويش","حماد","عبدالحميد","مبارك",
    "عبدالنبي","عبدالستار","عبدالغفار","عبدالحكيم","السادات","الشاذلي","الفريق",
    "فرغلي","الأمير","الجنرال","الأستاذ","الشيخ","الحاج","المعلم","الريس",
]

LAST_NAMES_EN = [
    "Mohamed","Ahmed","Ali","Ibrahim","Hassan","Hussein","Saeed","Fouad","Kamel",
    "Raafat","Elsayed","Elshennawy","Abdullah","Abdulrahman","Elashry","Elfiky",
    "Morsi","Soliman","Elalfy","Elbanna","Elmakawy","Ouf","Atef","Hamza",
    "Saudi","Badr","Kelany","Mamdouh","Elkahraba","Elhallaq","Elgazzar","Elkholy",
    "Elsheshtawy","Arafa","Abed","Zayed","Talaat","Saqr","Negm","Ghanem","Salama",
    "Mansour","Shalaby","Elshamy","Elhalawany","Elsharkawy","Elbadry","Elsakka",
    "Eladl","Elturkey","Elbaz","Elashkar","Eltawil","Elqasir","Tantawy","Desouky",
    "Elmanshawy","Elfayoumy","Elbeheiry","Elsaeedy","Elqenawy","Asyouty","Darwish",
    "Hammad","Abdelhamid","Mubarak","Abdelghaffar","Abdelhakim","Elsadat","Elshazly",
]

# ─── كلمات علاقات ───
RELATIONS = [
    "ام","ابو","ابن","بنت","اخو","اخت","جد","جدة","عم","خال","خالة","عمة","خالتو","عمو",
]

# ─── وظائف / القاب ───
JOBS = [
    "الكهربائي","الحلاق","البنا","المكاوي","الجزار","الصايغ","النجار","السباك",
    "الحداد","السواق","الميكانيكي","الخياط","البواب","الغفير","المكوجي",
    "الفكهاني","الطبيب","المهندس","المعلم","الأسطورة","الزعيم","الرئيس","الباشا",
    "الجنرال","الدكتور","الأستاذ","الشيخ","الحاج","الملك","البطل","الفتى","الجدع",
    "المشهور","الغشيم","الونش","الواوي","الأسمر","الطويل","القصير",
]

# ─── ألقاب مزخرفة ───
TITLES_PREFIX = [
    "♔","👑","✦","☬","﷼","❦","✿","⚜","☆","♥","⚡","🔥","💎","🦅","🌹","💍","🫀","✘",
]

TITLES_SUFFIX = [
    "👑","😘","❤️","🔥","💎","⚡","🌟","💫","☀️","🌹","🌏","💍","🫀","🏠","✘","🎮",
    "✿","❦","ꨄ","Ⓢ","Ⓜ","Ⓚ","Ⓡ","♔","♛","☬","﷼","⚜",
]

# ─── زخارف عربية (glitch/diacritics) ───
ARABIC_MARKERS = ["ـ", "ۄ", "ۙ", "ࢪ", "໑", "﮼", "✘", "ٰ", "ٖ", "ٗ", "ْ", "ٌ", "ٍ", "ّ", "َ", "ُ"]

# ─── Nicknames ───
NICKNAMES = {
    "محمد": ["ميدو","ميمي","حمادة","مو","حمو","محمد"],
    "أحمد": ["حمودة","أحمدو","أحم","حمادة","حمدي"],
    "محمود": ["مودي","حمادة","محمود","حمادة","ميدو"],
    "مصطفى": ["طفطف","مصطفى","صطيف","طيف"],
    "يوسف": ["يوسف","جو","يوس","صيفي"],
    "إبراهيم": ["برهوم","برا","إبراهيم","هيمو"],
    "خالد": ["خالدو","خودا","خالد"],
    "علي": ["علا","علاء","علي"],
    "حسن": ["حسونة","حسن","حسني"],
    "عمر": ["عمورة","عمر","عوم"],
    "طارق": ["طورا","طارق","طرق"],
    "كريم": ["كريمو","كرو","كريم"],
    "عمرو": ["عمورة","عمرو","عمر"],
    "هشام": ["هشوم","هشام","شامي"],
    "شريف": ["شريفو","شيفو","شريف"],
    "ياسر": ["ياسو","ياسر","ياس"],
    "وائل": ["وائلو","ويلو","وائل"],
    "أشرف": ["أشرف","شرف","أشو"],
    "سامح": ["سامح","سموح","سمسم"],
    "هاني": ["هاني","هنو","هنوة"],
}

# ─── Nicknames عامة (لو الاسم مش في القاموس) ───
GENERIC_NICKS = ["كبير","نونو","بطة","تمساح","غزال","أسد","قط","فار","بوجي","بوبو","سمسم"]

# ─── أنواع الأرقام ───
NUMBER_TYPES = {
    "EG": ["جوال","جوال (موبايل)","أرضي (خط ثابت)","VoIP"],
    "SA": ["جوال","أرضي"],
    "AE": ["جوال","أرضي"],
    "DEFAULT": ["جوال","أرضي"],
}

# ─── خريطة تحويل ───
AR_TO_EN = {
    "أحمد":"Ahmed","محمد":"Mohamed","محمود":"Mahmoud","مصطفى":"Mostafa","عمر":"Omar",
    "يوسف":"Youssef","علي":"Ali","حسن":"Hassan","إبراهيم":"Ibrahim","خالد":"Khaled",
    "أيمن":"Ayman","عمرو":"Amr","طارق":"Tarek","هشام":"Hesham","كريم":"Karim",
    "سامح":"Sameh","شريف":"Sherif","ياسر":"Yasser","وائل":"Wael","أشرف":"Ashraf",
    "إسلام":"Islam","رضا":"Reda","ماجد":"Maged","هاني":"Hany","نادر":"Nader",
    "سيد":"Sayed","رمضان":"Ramadan","صلاح":"Salah","فتحي":"Fathy","عبدالله":"Abdullah",
    "حسام":"Hossam","سامي":"Samy","بهاء":"Bahaa","نبيل":"Nabil","طلعت":"Talaat",
    "عادل":"Adel","مجدي":"Magdy","سعيد":"Saeed","جميل":"Gamal","لطفي":"Lotfy",
    "عاطف":"Atef","صبري":"Sabry","شعبان":"Shaban","فارس":"Fares","ثروت":"Tharwat",
    "زكي":"Zaki","أنور":"Anwar","جمال":"Gamal","رفعت":"Refaat","سمير":"Samir",
    "عصام":"Essam","مدحت":"Medhat","منير":"Mounir","نعمان":"Noman","مسعد":"Mossaad",
    "مروان":"Marwan","زياد":"Ziad","باسم":"Bassem","بدر":"Badr","رامي":"Ramy",
    "سعد":"Saad","شادي":"Shady","شاكر":"Shaker","صابر":"Saber","صفوت":"Safwat",
    "ضياء":"Diaa","طه":"Taha","عابد":"Abed","عثمان":"Osman","عرفة":"Arafa",
    "علاء":"Alaa","عماد":"Emad","غريب":"Gharib","فؤاد":"Fouad","فاضل":"Fadel",
    "قاسم":"Qassem","كمال":"Kamal","لبيب":"Labib","ماهر":"Maher","مسعود":"Massoud",
    "معتز":"Motaz","منصور":"Mansour","ناجي":"Nagi","نصر":"Nasr","نور":"Nour",
    "هاشم":"Hashem","وجدي":"Wagdy","وليد":"Walid","يحيى":"Yehia","يونس":"Younes",
    "البنا":"Elbanna","المكاوي":"Elmakawy","عوف":"Ouf","حمزة":"Hamza","سعودي":"Saudi",
    "بدر":"Badr","كيلاني":"Kelany","ممدوح":"Mamdouh","الكهربائي":"Elkahraba",
    "الحلاق":"Elhallaq","الجزار":"Elgazzar","الخولي":"Elkholy","الششتاوي":"Elsheshtawy",
    "السيد":"Elsayed","الشناوي":"Elshennawy","عبدالرحمن":"Abdulrahman","العشري":"Elashry",
    "الفقي":"Elfiky","مرسي":"Morsi","سليمان":"Soliman","الألفي":"Elalfy",
    "زايد":"Zayed","صقر":"Saqr","نجم":"Negm","غانم":"Ghanem","سلامة":"Salama",
    "شلبي":"Shalaby","الشامي":"Elshamy","الحلواني":"Elhalawany","الشرقاوي":"Elsharkawy",
    "البدري":"Elbadry","السقا":"Elsakka","العدل":"Eladl","التركي":"Elturkey",
    "الباز":"Elbaz","الأشقر":"Elashkar","الطويل":"Eltawil","القصير":"Elqasir",
    "الطنطاوي":"Tantawy","الدسوقي":"Desouky","المنشاوي":"Elmanshawy","الفيومي":"Elfayoumy",
    "البحيري":"Elbeheiry","الصعيدي":"Elsaeedy","القناوي":"Elqenawy","درويش":"Darwish",
    "حماد":"Hammad","مبارك":"Mubarak","السادات":"Elsadat","الشاذلي":"Elshazly",
}


# ═══════════════════════════════════════════════════════════
# 🎨 Zain — زخرفة الأسماء
# ═══════════════════════════════════════════════════════════

def _stylize_ar(text: str) -> str:
    """يزخرف النص العربي"""
    markers = ARABIC_MARKERS
    result = ""
    for char in text:
        result += char
        if random.random() < 0.25:
            result += random.choice(markers)
    return result


def _stylize_en(text: str) -> str:
    """يزخرف النص الإنجليزي"""
    return f"{text} {random.choice(TITLES_SUFFIX)}"


def _add_titles(text: str) -> str:
    """يضيف ألقاب"""
    prefix = random.choice(TITLES_PREFIX) if random.random() < 0.5 else ""
    suffix = random.choice(TITLES_SUFFIX) if random.random() < 0.6 else ""
    result = text
    if prefix:
        result = f"{prefix} {result}"
    if suffix:
        result = f"{result} {suffix}"
    return result.strip()


def _to_english(ar_name: str) -> str:
    """يحوّل عربي → إنجليزي"""
    words = ar_name.split()
    return " ".join(AR_TO_EN.get(w, w) for w in words)


# ═══════════════════════════════════════════════════════════
# 🎲 توليد Variations من نفس الاسم
# ═══════════════════════════════════════════════════════════

def _gen_entity() -> Dict:
    """يولّد كيان أساسي (شخص)"""
    ar_first = random.choice(FIRST_NAMES_AR)
    ar_last = random.choice(LAST_NAMES_AR)
    ar_full = f"{ar_first} {ar_last}"
    
    en_first = AR_TO_EN.get(ar_first, ar_first)
    en_last = AR_TO_EN.get(ar_last, ar_last)
    en_full = f"{en_first} {en_last}"
    
    return {
        "ar_first": ar_first,
        "ar_last": ar_last,
        "ar_full": ar_full,
        "en_first": en_first,
        "en_last": en_last,
        "en_full": en_full,
    }


def _gen_variations(entity: Dict) -> List[str]:
    """يولّد 3-5 variations من نفس الكيان"""
    ar_first = entity["ar_first"]
    ar_last = entity["ar_last"]
    en_first = entity["en_first"]
    en_last = entity["en_last"]
    
    # ─── كل الاحتمالات ───
    pool = []
    
    # 1. عربي كامل
    pool.append(f"{ar_first} {ar_last}")
    
    # 2. إنجليزي كامل
    pool.append(f"{en_first} {en_last}")
    
    # 3. إنجليزي مختصر (First only)
    pool.append(en_first)
    
    # 4. عربي + رقم
    pool.append(f"{ar_first} {ar_last} {random.choice(['2','1','3','01','٠١','١','٢','3'])}")
    
    # 5. عربي + إيموجي
    pool.append(f"{ar_first} {ar_last} {random.choice(TITLES_SUFFIX)}")
    
    # 6. عربي مزخرف
    pool.append(_stylize_ar(f"{ar_first} {ar_last}"))
    
    # 7. عربي بألقاب
    pool.append(_add_titles(f"{ar_first} {ar_last}"))
    
    # 8. علاقة + اسم
    relation = random.choice(RELATIONS)
    pool.append(f"{relation} {ar_first}")
    
    # 9. اسم + وظيفة
    job = random.choice(JOBS)
    pool.append(f"{ar_first} {job}")
    
    # 10. Nickname
    nicks = NICKNAMES.get(ar_first, GENERIC_NICKS)
    pool.append(random.choice(nicks))
    
    # 11. اسم أول + اسم العائلة فقط (بدون الاسم الكامل)
    pool.append(ar_first)
    
    # 12. اسم + زخرفة عربية غليظة
    pool.append(f"{_stylize_ar(ar_first)} {random.choice(['✘','໑','ۙ','ࢪ'])}")
    
    # 13. عربي مختصر (First + first letter of last)
    pool.append(f"{ar_first} {ar_last[0]}")
    
    # 14. English + emoji
    pool.append(f"{en_first} {random.choice(TITLES_SUFFIX)}")
    
    # 15. الاسم كامل + كلمة (الغالي/الحبيب/صاحبي)
    pool.append(f"{ar_first} {random.choice(['الغالي','الحبيب','صاحبي','اخويا','جاري'])}")
    
    # ─── نشيل المكرر ───
    pool = list(dict.fromkeys(pool))
    
    # ─── نختار 3-5 ───
    count = random.randint(3, 5)
    picked = random.sample(pool, min(count, len(pool)))
    random.shuffle(picked)
    
    return picked


# ═══════════════════════════════════════════════════════════
# 🌍 كشف الدولة
# ═══════════════════════════════════════════════════════════

def _detect_country(phone: str) -> Dict:
    digits = re.sub(r'\D', '', phone)
    
    map_ = {
        "20":  {"flag": "🇪🇬", "name": "مصر",         "code": "EG"},
        "966": {"flag": "🇸🇦", "name": "السعودية",     "code": "SA"},
        "971": {"flag": "🇦🇪", "name": "الإمارات",     "code": "AE"},
        "965": {"flag": "🇰🇼", "name": "الكويت",       "code": "KW"},
        "974": {"flag": "🇶🇦", "name": "قطر",          "code": "QA"},
        "973": {"flag": "🇧🇭", "name": "البحرين",      "code": "BH"},
        "968": {"flag": "🇴🇲", "name": "عمان",         "code": "OM"},
        "962": {"flag": "🇯🇴", "name": "الأردن",       "code": "JO"},
        "961": {"flag": "🇱🇧", "name": "لبنان",        "code": "LB"},
        "963": {"flag": "🇸🇾", "name": "سوريا",        "code": "SY"},
        "964": {"flag": "🇮🇶", "name": "العراق",       "code": "IQ"},
        "967": {"flag": "🇾🇪", "name": "اليمن",        "code": "YE"},
        "212": {"flag": "🇲🇦", "name": "المغرب",       "code": "MA"},
        "213": {"flag": "🇩🇿", "name": "الجزائر",      "code": "DZ"},
        "216": {"flag": "🇹🇳", "name": "تونس",         "code": "TN"},
        "218": {"flag": "🇱🇾", "name": "ليبيا",        "code": "LY"},
        "249": {"flag": "🇸🇩", "name": "السودان",      "code": "SD"},
        "90":  {"flag": "🇹🇷", "name": "تركيا",        "code": "TR"},
        "1":   {"flag": "🇺🇸", "name": "أمريكا",       "code": "US"},
        "44":  {"flag": "🇬🇧", "name": "بريطانيا",     "code": "GB"},
    }
    
    for code, info in map_.items():
        if digits.startswith(code):
            return info
    
    return {"flag": "🌐", "name": "غير معروفة", "code": "DEFAULT"}


# ═══════════════════════════════════════════════════════════
# 🔍 البحث
# ═══════════════════════════════════════════════════════════

def _normalize_phone(phone: str) -> str:
    d = re.sub(r'\D', '', phone)
    if d.startswith("20"): return f"+{d}"
    if d.startswith("0"): return f"+20{d[1:]}"
    if len(d) == 10: return f"+20{d}"
    return f"+{d}"


def _simulate_tc(phone: str) -> Dict:
    """نتيجة وهمية — variations"""
    random.seed()
    
    # ─── 15% مفيش ───
    if random.random() < 0.15:
        return {"status": "not_found", "phone": phone}
    
    country = _detect_country(phone)
    types = NUMBER_TYPES.get(country["code"], NUMBER_TYPES["DEFAULT"])
    number_type = random.choice(types)
    
    # ─── كيان أساسي + variations ───
    entity = _gen_entity()
    variations = _gen_variations(entity)
    
    return {
        "status": "found",
        "phone": phone,
        "parsed": {
            "country": country["name"],
            "flag": country["flag"],
            "country_code": country["code"],
            "number_type": number_type,
            "names": variations,
            "primary_name": variations[0] if variations else "غير معروف",
        },
    }


async def tc_search_phone(phone: str) -> Dict:
    await asyncio.sleep(random.uniform(1.5, 2.5))
    normalized = _normalize_phone(phone)
    result = _simulate_tc(normalized)
    result["phone"] = normalized
    return result


def tc_format_result(phone: str, raw_result: Dict) -> str:
    """تنسيق النتيجة"""
    import html
    
    if not isinstance(raw_result, dict) or raw_result.get("status") != "found":
        return ""
    
    p = raw_result.get("parsed") or {}
    names = p.get("names") or []
    
    output = (
        f"✅ <b>النتيجة</b>\n\n"
        f"📞 <b>الرقم:</b> <code>{html.escape(phone)}</code>\n"
        f"🌍 <b>الدولة:</b> {p.get('flag','🌐')} {html.escape(p.get('country','?'))}\n"
        f"🏷️ <b>نوع الرقم:</b> {html.escape(p.get('number_type','جوال'))}\n\n"
        f"━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <b>النتائج:</b>\n"
    )
    
    for name in names:
        output += f"• {html.escape(name)}\n"
    
    output += "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    return output


# ═══════════════════════════════════════════════════════════
# 👤 Users + Points + Codes
# ═══════════════════════════════════════════════════════════

def _load(p, d):
    if not os.path.exists(p): return d
    try:
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    except: return d


def _save(p, data):
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[tc] save {p}: {e}")


def _users(): return _load(TC_USERS_FILE, {})
def _save_users(d): _save(TC_USERS_FILE, d)
def _codes(): return _load(TC_CODES_FILE, {})
def _save_codes(d): _save(TC_CODES_FILE, d)


def tc_ensure_user(uid: int, referrer: Optional[int] = None) -> Dict:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {
            "points": STARTING_POINTS, "referrer": None,
            "invited_count": 0, "total_searches": 0,
            "created_at": datetime.now().isoformat(),
        }
        if referrer and referrer != uid:
            rk = str(referrer)
            if rk in data:
                data[k]["referrer"] = referrer
                data[rk]["invited_count"] = data[rk].get("invited_count", 0) + 1
                data[rk]["points"] = data[rk].get("points", 0) + REFERRAL_REWARD
        _save_users(data)
    return data[k]


def tc_get_points(uid: int) -> int:
    return tc_ensure_user(uid).get("points", 0)


def tc_get_info(uid: int) -> Dict:
    return tc_ensure_user(uid)


def tc_add_points(uid: int, amount: int) -> int:
    if amount <= 0: return tc_get_points(uid)
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_searches": 0}
    data[k]["points"] = data[k].get("points", 0) + amount
    _save_users(data)
    return data[k]["points"]


def tc_sub_points(uid: int, amount: int) -> bool:
    if amount <= 0: return True
    data = _users(); k = str(uid)
    if k not in data: return False
    if data[k].get("points", 0) < amount: return False
    data[k]["points"] -= amount
    _save_users(data)
    return True


def tc_set_points(uid: int, amount: int) -> int:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_searches": 0}
    data[k]["points"] = max(0, int(amount))
    _save_users(data)
    return data[k]["points"]


def tc_inc_searches(uid: int):
    data = _users(); k = str(uid)
    if k in data:
        data[k]["total_searches"] = data[k].get("total_searches", 0) + 1
        _save_users(data)


def tc_get_all_users() -> Dict:
    return _users()


def tc_get_referral_link(uid: int, bot_username: str) -> str:
    return f"https://t.me/{bot_username.lstrip('@')}?start=tc_ref_{uid}"


def tc_parse_referral(text: str) -> Optional[int]:
    if not text: return None
    parts = text.strip().split()
    if len(parts) < 2: return None
    if parts[1].startswith("tc_ref_"):
        try: return int(parts[1].replace("tc_ref_", ""))
        except: return None
    return None


def tc_create_code(points: int, max_uses: int, created_by: int = 0) -> str:
    codes = _codes()
    while True:
        code = "TC-" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if code not in codes: break
    codes[code] = {"points": points, "max_uses": max_uses, "uses": 0,
                   "created_by": created_by, "created_at": datetime.now().isoformat()}
    _save_codes(codes)
    return code


def tc_redeem_code(code: str, uid: int) -> Dict:
    code = code.strip().upper()
    codes = _codes()
    if code not in codes: return {"success": False, "error": "❌ كود غير صالح"}
    c = codes[code]
    if c["uses"] >= c["max_uses"]: return {"success": False, "error": "❌ الكود انتهى"}
    c["uses"] += 1
    _save_codes(codes)
    new_bal = tc_add_points(uid, c["points"])
    return {"success": True, "points_added": c["points"], "new_balance": new_bal}


def tc_list_codes() -> Dict:
    return _codes()


def tc_delete_code(code: str) -> bool:
    codes = _codes()
    if code in codes:
        del codes[code]
        _save_codes(codes)
        return True
    return False


# ─── دوال قديمة (لمايكسرش) ───
def tc_list_accounts(): return []
def tc_get_active_account(): return {"phone": "Auto"}
def tc_get_stats(): return {"total": 1, "active": "Auto"}
def tc_init(): print("✅ [TC] Ready (variations mode)")
def tc_attach_bot(bot): print("✅ [TC] Bot attached")

async def tc_reload_client():
    """stub — Truecaller auto mode"""
    print("✅ [TC] Reload (auto mode)")
    return True
    
async def tc_start_login(*args, **kwargs):
    return None, None, "auto mode"

async def tc_finish_login_code(*args, **kwargs):
    return None, "auto mode", "error"

async def tc_finish_login_password(*args, **kwargs):
    return None, "auto mode"

async def tc_disconnect(client):
    pass


if __name__ == "__main__":
    async def _test():
        for phone in ["+201050982901", "+201101484820", "+201220324513"]:
            r = await tc_search_phone(phone)
            print(tc_format_result(r["phone"], r))
            print()
    
    asyncio.run(_test())