# ═══════════════════════════════════════════════════════════
# 📘 FACE CHECK v3 — توليد فيسبوك من رقم + نقاط
# ═══════════════════════════════════════════════════════════
# مدخل: رقم تليفون
# مخرج: حساب فيسبوك وهمي كامل
# ═══════════════════════════════════════════════════════════

import os, re, json, random, asyncio, string
from datetime import datetime, timedelta
from typing import Dict, List, Optional


FACE_DIR     = "face_data"
FACE_USERS   = os.path.join(FACE_DIR, "users.json")
FACE_CODES   = os.path.join(FACE_DIR, "codes.json")
os.makedirs(FACE_DIR, exist_ok=True)

STARTING_POINTS = 3
FACE_COST       = 1
REFERRAL_REWARD = 1


# ─── الأسماء ───
FIRST_NAMES = ["Ahmed","Mohamed","Mahmoud","Mostafa","Omar","Youssef","Ali","Hassan","Ibrahim","Khaled","Ayman","Amr","Tarek","Hesham","Karim","Sameh","Sherif","Yasser","Wael","Ashraf","Islam","Reda","Maged","Hany","Ahmed","Moataz","Hatem","Bassem","Ramy","Fady"]
LAST_NAMES  = ["Mohamed","Ali","Ahmed","Ibrahim","Mostafa","Hassan","Fouad","Samy","Kamel","Raafat","Elsayed","Elshennawy","Elsheshtawy","Elgazzar","Abdelaziz","Elashry","Elfiky","Morsi","Soliman","Elalfy","Ramadan","Nasser","Zaki","Farouk","Shawky"]

CITIES = [
    ("Cairo","Egypt"),("Alexandria","Egypt"),("Giza","Egypt"),
    ("Luxor","Egypt"),("Aswan","Egypt"),("Mansoura","Egypt"),
    ("Tanta","Egypt"),("Suez","Egypt"),("Port Said","Egypt"),
]

JOBS = ["Software Engineer","Doctor","Accountant","Teacher","Pharmacist",
        "Engineer","Business Owner","Journalist","Lawyer","Designer",
        "Studied at Cairo University","Studied at Ain Shams University",
        "Works at Vodafone","Works at Orange","Works at Microsoft"]

RELATIONSHIPS = ["Single","Married","In a relationship","Engaged","It's complicated"]


# ═══════════════════════════════════════════════════════════
# 💾 IO
# ═══════════════════════════════════════════════════════════

def _load(p, d):
    if not os.path.exists(p): return d
    try:
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    except: return d


def _save(p, data):
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[face] save {p}: {e}")


def _users(): return _load(FACE_USERS, {})
def _save_users(d): _save(FACE_USERS, d)
def _codes(): return _load(FACE_CODES, {})
def _save_codes(d): _save(FACE_CODES, d)


# ═══════════════════════════════════════════════════════════
# 👤 Users + Points
# ═══════════════════════════════════════════════════════════

def face_ensure_user(uid: int, referrer: Optional[int] = None) -> Dict:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {
            "points": STARTING_POINTS, "referrer": None,
            "invited_count": 0, "total_checks": 0,
            "created_at": datetime.now().isoformat(),
        }
        if referrer and referrer != uid:
            rk = str(referrer)
            if rk in data:
                data[k]["referrer"] = referrer
                data[rk]["invited_count"] = data[rk].get("invited_count", 0) + 1
                data[rk]["points"] = data[rk].get("points", 0) + REFERRAL_REWARD
        _save_users(data)
    return data[k]


def face_get_user_points(uid: int) -> int:
    return face_ensure_user(uid).get("points", 0)


def face_get_user_info(uid: int) -> Dict:
    return face_ensure_user(uid)


def face_add_points(uid: int, amount: int) -> int:
    if amount <= 0: return face_get_user_points(uid)
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_checks": 0}
    data[k]["points"] = data[k].get("points", 0) + amount
    _save_users(data)
    return data[k]["points"]


def face_sub_points(uid: int, amount: int) -> bool:
    if amount <= 0: return True
    data = _users(); k = str(uid)
    if k not in data: return False
    if data[k].get("points", 0) < amount: return False
    data[k]["points"] -= amount
    _save_users(data)
    return True


def face_set_points(uid: int, amount: int) -> int:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_checks": 0}
    data[k]["points"] = max(0, int(amount))
    _save_users(data)
    return data[k]["points"]


def face_inc_checks(uid: int):
    data = _users(); k = str(uid)
    if k in data:
        data[k]["total_checks"] = data[k].get("total_checks", 0) + 1
        _save_users(data)


def face_get_all_users() -> Dict:
    return _users()


def face_get_referral_link(uid: int, bot_username: str) -> str:
    return f"https://t.me/{bot_username.lstrip('@')}?start=face_ref_{uid}"


def face_parse_referral(text: str) -> Optional[int]:
    if not text: return None
    parts = text.strip().split()
    if len(parts) < 2: return None
    if parts[1].startswith("face_ref_"):
        try: return int(parts[1].replace("face_ref_", ""))
        except: return None
    return None


# ─── أكواد ───
def face_create_code(points: int, max_uses: int, created_by: int = 0) -> str:
    codes = _codes()
    while True:
        code = "FACE-" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if code not in codes: break
    codes[code] = {"points": points, "max_uses": max_uses, "uses": 0,
                   "created_by": created_by, "created_at": datetime.now().isoformat()}
    _save_codes(codes)
    return code


def face_redeem_code(code: str, uid: int) -> Dict:
    code = code.strip().upper()
    codes = _codes()
    if code not in codes: return {"success": False, "error": "❌ كود غير صالح"}
    c = codes[code]
    if c["uses"] >= c["max_uses"]: return {"success": False, "error": "❌ الكود انتهى"}
    c["uses"] += 1
    _save_codes(codes)
    new_bal = face_add_points(uid, c["points"])
    return {"success": True, "points_added": c["points"], "new_balance": new_bal}


def face_get_stats() -> Dict:
    return {"total": len(_users()), "active": "Auto"}


# ═══════════════════════════════════════════════════════════
# 🌐 توليد فيسبوك من رقم
# ═══════════════════════════════════════════════════════════

def _generate_facebook(phone: str) -> Dict:
    """يولّد حساب فيسبوك وهمي كامل"""
    first = random.choice(FIRST_NAMES)
    last = random.choice(LAST_NAMES)
    full_name = f"{first} {last}"
    
    # ─── يوزر نيم ───
    base_user = f"{first.lower()}.{last.lower()}"
    suffix_num = random.randint(1, 9999)
    username = f"{base_user}.{suffix_num}"
    profile_url = f"https://facebook.com/{username}"
    
    # ─── ID ───
    fb_id = str(random.randint(100000000, 999999999))
    
    # ─── الإيميل ───
    email = f"{base_user}{suffix_num}@{random.choice(['gmail.com','yahoo.com','outlook.com','hotmail.com'])}"
    
    # ─── تاريخ الميلاد ───
    birth_year = random.randint(1970, 2005)
    birth_month = random.randint(1, 12)
    birth_day = random.randint(1, 28)
    birth_date = f"{birth_day:02d}/{birth_month:02d}/{birth_year}"
    age = datetime.now().year - birth_year
    
    # ─── البلد ───
    city, country = random.choice(CITIES)
    location = f"{city}, {country}"
    
    # ─── حالة اجتماعية ───
    relationship = random.choice(RELATIONSHIPS)
    
    # ─── عمل ───
    job = random.choice(JOBS)
    
    # ─── عدد الأصدقاء / الصور ───
    friends = random.randint(100, 5000)
    photos = random.randint(20, 2000)
    posts = random.randint(10, 800)
    
    # ─── تاريخ إنشاء الحساب ───
    created_year = random.randint(2010, 2023)
    created_month = random.randint(1, 12)
    created_day = random.randint(1, 28)
    created = f"{created_day:02d}/{created_month:02d}/{created_year}"
    
    # ─── آخر نشاط ───
    activity_options = ["نشط الآن","آخر ظهور قبل 5 دقايق","آخر ظهور قبل ساعة","آخر ظهور النهاردة","آخر ظهور أمس","آخر ظهور الأسبوع ده"]
    last_active = random.choice(activity_options)
    
    return {
        "phone": phone,
        "fb_id": fb_id,
        "name": full_name,
        "username": username,
        "profile_url": profile_url,
        "email": email,
        "birth_date": birth_date,
        "age": age,
        "location": location,
        "relationship": relationship,
        "job": job,
        "friends": friends,
        "photos": photos,
        "posts": posts,
        "created": created,
        "last_active": last_active,
    }


async def face_lookup_phone(phone: str) -> Dict:
    """البحث — توليد فيسبوك وهمي"""
    await asyncio.sleep(random.uniform(1.5, 2.5))
    
    phone_clean = re.sub(r'[^\d+]', '', phone)
    if not phone_clean.startswith("+"):
        phone_clean = "+" + phone_clean
    
    return {
        "success": True,
        "phone": phone_clean,
        "data": _generate_facebook(phone_clean),
        "timestamp": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════════
# 🎯 ROUTER
# ═══════════════════════════════════════════════════════════

FACE_STATES: Dict[int, dict] = {}

def _st(uid): return FACE_STATES.setdefault(uid, {})
def _reset(uid): FACE_STATES[uid] = {}


async def face_check_router(event, uid: int, data: str):
    """Router Face"""
    sub = data.replace("face:", "")
    is_admin_user = uid in ADMIN_IDS if 'ADMIN_IDS' in globals() else False
    
    # ═══ الرئيسية ═══
    if sub == "home":
        _reset(uid)
        pts = face_get_user_points(uid)
        info = face_get_user_info(uid)
        
        buttons = [
            [Button.inline("🔍 ابدأ الفحص", b"face:start")],
            [Button.inline("💰 نقاطي", b"face:points"),
             Button.inline("🔗 الإحالة", b"face:referral")],
            [Button.inline("🎫 استبدال كود", b"face:redeem")],
        ]
        if is_admin_user:
            buttons.append([
                Button.inline("📊 إحصائيات", b"face:adm:stats"),
                Button.inline("🎫 صنع كود", b"face:adm:code"),
            ])
            buttons.append([Button.inline("➕ إضافة نقاط", b"face:adm:add")])
        buttons.append([Button.inline("↩️ رجوع", b"menu:home")])
        
        try:
            await event.edit(
                "📘━━━━━━━━━━━━━━━━━━━━━━━━📘\n"
                "     <b>𝗙𝗔𝗖𝗘 𝗮.𝗖𝗛𝗘𝗖𝗞</b>\n"
                "📘━━━━━━━━━━━━━━━━━━━━━━━━📘\n\n"
                "🎯 <b>توليد فيسبوك من رقم</b>\n\n"
                "━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"💰 <b>نقاطك:</b> <code>{pts}</code>\n"
                f"👥 <b>إحالاتك:</b> <code>{info.get('invited_count',0)}</code>\n"
                f"📊 <b>عمليات الفحص:</b> <code>{info.get('total_checks',0)}</code>\n"
                "━━━━━━━━━━━━━━━━━━━━━━━\n\n"
                "📋 <b>هيرجعلك:</b>\n"
                "   • 👤 الاسم الكامل\n"
                "   • 🔗 رابط البروفايل\n"
                "   • 📧 إيميل\n"
                "   • 🎂 تاريخ الميلاد\n"
                "   • 📍 المكان\n"
                "   • 👥 عدد الأصدقاء\n"
                "   • 📸 عدد الصور",
                buttons=buttons,
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ بدء ═══
    if sub == "start":
        if not is_admin_user:
            if face_get_user_points(uid) < FACE_COST:
                await event.answer("❌ نقاطك مش كافية!\n🔗 شارك رابط الإحالة", alert=True)
                return
        _reset(uid); _st(uid)["flow"] = "wait_phone"
        try:
            await event.edit(
                "📱 <b>ابعت رقم التليفون:</b>\n\n"
                "💡 أمثلة:\n"
                "   • <code>+201012345678</code>\n"
                "   • <code>01012345678</code>\n\n"
                f"💰 <b>التكلفة:</b> <code>{FACE_COST} نقطة</code>",
                buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ نقاطي ═══
    if sub == "points":
        pts = face_get_user_points(uid)
        info = face_get_user_info(uid)
        try:
            await event.edit(
                f"💰 <b>نقاطي</b>\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"⭐ <b>الرصيد:</b> <code>{pts}</code>\n"
                f"👥 <b>الإحالات:</b> <code>{info.get('invited_count',0)}</code>\n"
                f"📊 <b>عمليات الفحص:</b> <code>{info.get('total_checks',0)}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━",
                buttons=[
                    [Button.inline("🔗 الإحالة", b"face:referral")],
                    [Button.inline("🎫 كود", b"face:redeem")],
                    [Button.inline("↩️ رجوع", b"face:home")],
                ],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ الإحالة ═══
    if sub == "referral":
        try:
            me = await bot.get_me()
            link = face_get_referral_link(uid, me.username or "")
            info = face_get_user_info(uid)
            await event.edit(
                f"🔗 <b>رابط الإحالة</b>\n\n"
                f"<code>{link}</code>\n\n"
                f"👥 <b>إحالاتك:</b> <code>{info.get('invited_count',0)}</code>\n\n"
                f"🎁 <b>كل واحد يدخل من الرابط:</b>\n"
                f"   ⭐ <b>+1 نقطة لك</b>\n"
                f"   ⭐ <b>+3 نقاط له</b>",
                buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                parse_mode="html",
            )
        except Exception as e:
            await event.answer(f"❌ {str(e)[:50]}", alert=True)
        return
    
    # ═══ كود ═══
    if sub == "redeem":
        _reset(uid); _st(uid)["flow"] = "wait_code"
        try:
            await event.edit(
                "🎫 <b>استبدال كود</b>\n\n📥 ابعت الكود:",
                buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ أوامر الأدمن ═══
    if sub.startswith("adm:"):
        if not is_admin_user:
            await event.answer("⛔ أدمن فقط!", alert=True)
            return
        action = sub.replace("adm:", "")
        
        if action == "code":
            _reset(uid); _st(uid)["flow"] = "admin_code"
            try:
                await event.edit(
                    "🎫 <b>إنشاء كود</b>\n\n"
                    "📝 ابعت: <code>النقاط : عدد الاستخدامات</code>",
                    buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                    parse_mode="html",
                )
            except: pass
            return
        
        if action == "add":
            _reset(uid); _st(uid)["flow"] = "admin_add"
            try:
                await event.edit(
                    "➕ <b>إضافة نقاط</b>\n\n"
                    "📝 ابعت: <code>الآيدي : النقاط</code>",
                    buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                    parse_mode="html",
                )
            except: pass
            return
        
        if action == "stats":
            users = face_get_all_users()
            tp = sum(u.get("points", 0) for u in users.values())
            tc = sum(u.get("total_checks", 0) for u in users.values())
            try:
                await event.edit(
                    f"📊 <b>إحصائيات Face</b>\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"👥 <b>المستخدمين:</b> <code>{len(users)}</code>\n"
                    f"⭐ <b>إجمالي النقاط:</b> <code>{tp}</code>\n"
                    f"📊 <b>عمليات الفحص:</b> <code>{tc}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━",
                    buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                    parse_mode="html",
                )
            except: pass
            return
    
    await event.answer("خيار غير معروف", alert=True)


# ═══════════════════════════════════════════════════════════
# ✍️ Text Handler
# ═══════════════════════════════════════════════════════════

async def face_check_text_handler(event, uid: int, text: str) -> bool:
    st = _st(uid)
    flow = st.get("flow")
    is_admin_user = uid in ADMIN_IDS if 'ADMIN_IDS' in globals() else False
    
    if not flow: return False
    
    # ═══ فحص ═══
    if flow == "wait_phone":
        phone = text.strip()
        digits = re.sub(r'\D', '', phone)
        if len(digits) < 8:
            await event.respond("❌ رقم غير صحيح")
            return True
        
        if not is_admin_user:
            if not face_sub_points(uid, FACE_COST):
                await event.respond(
                    f"❌ <b>نقاطك مش كافية!</b>\n💰 رصيدك: <code>{face_get_user_points(uid)}</code>",
                    parse_mode="html",
                    buttons=[[Button.inline("🔗 الإحالة", b"face:referral")],
                             [Button.inline("🎫 كود", b"face:redeem")]],
                )
                _reset(uid); return True
        
        msg = await event.respond("⏳ <b>جاري الفحص...</b>", parse_mode="html")
        
        try:
            result = await face_lookup_phone(phone)
            if result.get("success"):
                face_inc_checks(uid)
                new_bal = face_get_user_points(uid)
                d = result["data"]
                
                if is_admin_user:
                    balance_line = "👑 <b>أدمن — مجاني</b>"
                else:
                    balance_line = f"⭐ <b>رصيدك:</b> <code>{new_bal}</code>"
                
                output = (
                    f"✅━━━━━━━━━━━━━━━━━━━━━━━━✅\n"
                    f"     <b>𝗙𝗮𝗰𝗲𝗯𝗼𝗼𝗸 𝗙𝗼𝘂𝗻𝗱</b>\n"
                    f"✅━━━━━━━━━━━━━━━━━━━━━━━━✅\n\n"
                    f"📱 <b>الرقم:</b>\n<code>{result['phone']}</code>\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"👤 <b>الاسم:</b> <b>{d['name']}</b>\n"
                    f"🆔 <b>ID:</b> <code>{d['fb_id']}</code>\n"
                    f"🔗 <b>البروفايل:</b>\n{d['profile_url']}\n\n"
                    f"📧 <b>الإيميل:</b>\n<code>{d['email']}</code>\n\n"
                    f"🎂 <b>الميلاد:</b> {d['birth_date']}\n"
                    f"🎈 <b>العمر:</b> {d['age']} سنة\n"
                    f"📍 <b>المكان:</b> {d['location']}\n"
                    f"💼 <b>الوظيفة:</b> {d['job']}\n"
                    f"💍 <b>الحالة:</b> {d['relationship']}\n\n"
                    f"👥 <b>الأصدقاء:</b> <code>{d['friends']:,}</code>\n"
                    f"📸 <b>الصور:</b> <code>{d['photos']:,}</code>\n"
                    f"📝 <b>المنشورات:</b> <code>{d['posts']:,}</code>\n\n"
                    f"📅 <b>تاريخ الإنشاء:</b> {d['created']}\n"
                    f"🟢 <b>آخر نشاط:</b> {d['last_active']}\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"{balance_line}\n"
                    f"🦊 <b>FOX FACE</b>"
                )
                
                await msg.edit(
                    output[:4000],
                    buttons=[
                        [Button.inline("🔍 فحص تاني", b"face:start")],
                        [Button.inline("💰 نقاطي", b"face:points")],
                        [Button.inline("↩️ رجوع", b"face:home")],
                    ],
                    parse_mode="html",
                )
            else:
                if not is_admin_user:
                    face_add_points(uid, FACE_COST)
                await msg.edit(
                    "❌ <b>فشل الفحص</b>\n✅ <i>تم استرجاع النقطة</i>",
                    buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                    parse_mode="html",
                )
        except Exception as e:
            if not is_admin_user:
                face_add_points(uid, FACE_COST)
            await msg.edit(f"❌ <b>خطأ:</b>\n<code>{str(e)[:200]}</code>",
                           parse_mode="html")
        
        _reset(uid); return True
    
    # ═══ كود ═══
    if flow == "wait_code":
        code = text.strip().upper()
        result = face_redeem_code(code, uid)
        _reset(uid)
        if result.get("success"):
            await event.respond(
                f"✅ <b>تم استبدال الكود!</b>\n\n"
                f"🎫 <code>{code}</code>\n"
                f"⭐ <b>+{result['points_added']}</b>\n"
                f"💰 <b>رصيدك:</b> <code>{result['new_balance']}</code>",
                buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
                parse_mode="html",
            )
        else:
            await event.respond(result.get("error", "❌ خطأ"),
                                buttons=[[Button.inline("↩️ رجوع", b"face:home")]])
        return True
    
    # ═══ أدمن كود ═══
    if flow == "admin_code":
        if not is_admin_user:
            _reset(uid); return True
        try:
            parts = text.split(":")
            if len(parts) != 2: raise ValueError
            pts = int(parts[0].strip()); uses = int(parts[1].strip())
            if pts <= 0 or uses <= 0: raise ValueError
        except:
            await event.respond("❌ صيغة: `5 : 10`", parse_mode="html")
            return True
        code = face_create_code(pts, uses, uid)
        _reset(uid)
        await event.respond(
            f"✅ <b>تم إنشاء الكود!</b>\n\n"
            f"🎫 <code>{code}</code>\n"
            f"⭐ <code>{pts}</code> | 📊 <code>{uses}</code>",
            buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
            parse_mode="html",
        )
        return True
    
    # ═══ أدمن إضافة ═══
    if flow == "admin_add":
        if not is_admin_user:
            _reset(uid); return True
        try:
            parts = text.split(":")
            if len(parts) != 2: raise ValueError
            tid = int(parts[0].strip()); pts = int(parts[1].strip())
        except:
            await event.respond("❌ صيغة: `123456 : 50`", parse_mode="html")
            return True
        new_bal = face_add_points(tid, pts)
        _reset(uid)
        await event.respond(
            f"✅ <b>تم!</b>\n👤 <code>{tid}</code>\n⭐ <code>+{pts}</code>\n💰 <code>{new_bal}</code>",
            buttons=[[Button.inline("↩️ رجوع", b"face:home")]],
            parse_mode="html",
        )
        return True
    
    return False


# ─── دوال قديمة (لمايكسرش) ───
FACE_COUNTRIES = {"EG": ("مصر","+20",10,["10","11","12","15"])}


async def face_run_check(*args, **kwargs):
    return {"good": 0, "bad": 0, "total": 0, "stopped": True}