# ═══════════════════════════════════════════════════════════════════════
# 🧨 BOT DELETER — Standalone Pyrogram App
# ═══════════════════════════════════════════════════════════════════════

import sys
import json
import asyncio
from pyrogram import Client
from pyrogram.raw.functions.account import UpdateUsername

DELETE_API_ID = 9398500
DELETE_API_HASH = "ad2977d673006bed6e5007d953301e13"


async def disable_bot(target_token: str) -> dict:
    """تطير البوت"""
    result = {
        "success": False,
        "bot_id": None,
        "bot_username": None,
        "bot_name": None,
        "left_chats": 0,
        "error": None,
        "username_changed": False,
        "username_error": None,
    }

    temp_client = None

    try:
        # ─── فتح الجلسة ───
        temp_client = Client(
            "disable_session",
            api_id=DELETE_API_ID,
            api_hash=DELETE_API_HASH,
            bot_token=target_token,
            in_memory=True,
        )
        await temp_client.start()
        bot_info = await temp_client.get_me()

        result["bot_id"] = bot_info.id
        result["bot_username"] = bot_info.username
        result["bot_name"] = bot_info.first_name

        # ─── محاولة تغيير اليوزرنيم ───
        try:
            await temp_client.invoke(
                UpdateUsername(username=f"disabled_{bot_info.id}")
            )
            result["username_changed"] = True
        except Exception as e:
            result["username_error"] = str(e)[:150]

        # ─── leave الجروبات ───
        left = 0
        try:
            async for dialog in temp_client.get_dialogs():
                try:
                    if dialog.chat.type in ["group", "supergroup", "channel"]:
                        try:
                            await temp_client.leave_chat(dialog.chat.id)
                            left += 1
                        except Exception:
                            pass
                except Exception:
                    pass
        except Exception as e:
            print(f"[botdel] leave error: {e}")

        result["left_chats"] = left

        # ─── نحدد النتيجة ───
        if result["username_changed"]:
            result["success"] = True
        elif left > 0:
            result["success"] = True
        else:
            # حتى لو مفيش حاجة اتغيرت، البوت مسك التوكن
            result["success"] = True
            if result["username_error"]:
                result["error"] = f"⚠️ تلغرام رافضة التعديل: {result['username_error']}"

        await asyncio.sleep(2)
        return result

    except Exception as e:
        err_str = str(e)
        if "AccessTokenInvalid" in err_str or "TOKEN_INVALID" in err_str:
            result["error"] = "Invalid Token"
        elif "AccessTokenExpired" in err_str or "TOKEN_EXPIRED" in err_str:
            result["error"] = "Token Expired"
        else:
            result["error"] = err_str[:200]
        return result

    finally:
        if temp_client:
            try:
                await temp_client.stop()
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════
# Main
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "error": "No token provided"}))
        sys.exit(1)

    token = sys.argv[1]

    try:
        result = asyncio.run(disable_bot(token))
    except Exception as e:
        result = {
            "success": False,
            "bot_id": None,
            "bot_username": None,
            "bot_name": None,
            "left_chats": 0,
            "error": f"Fatal: {str(e)[:200]}",
        }

    print(json.dumps(result))