# ═══════════════════════════════════════════════════════════
# 📊 DATA EXTRACT v2 — بيانات مصرية وهمية + نقاط
# ═══════════════════════════════════════════════════════════
# مدخل: رقم تليفون
# مخرج: اسم رباعي + عنوان تفصيلي + رقم قومي + وظيفة + إيميل
# ═══════════════════════════════════════════════════════════

import os, re, json, random, asyncio, string
from datetime import datetime, timedelta
from typing import Dict, List, Optional


DATA_DIR      = "data_extract"
DATA_USERS    = os.path.join(DATA_DIR, "users.json")
DATA_CODES    = os.path.join(DATA_DIR, "codes.json")
os.makedirs(DATA_DIR, exist_ok=True)

DATA_DEVELOPER_ID = 7880029113
STARTING_POINTS = 3
LOOKUP_COST     = 1
REFERRAL_REWARD = 1


# ─── الاسم ───
FIRST_NAMES = ["أحمد","محمد","محمود","مصطفى","عمر","يوسف","علي","حسن","إبراهيم","خالد","أيمن","عمرو","طارق","هشام","كريم","سامح","شريف","ياسر","وائل","أشرف","إسلام","أيمن","رضا","ماجد","هاني"]
MIDDLE_NAMES = ["محمد","أحمد","علي","إبراهيم","مصطفى","حسن","حسين","سعيد","عبدالله","عبدالرحمن","فتحي","كمال","فؤاد"]
FAMILY_NAMES = ["محمد","علي","أحمد","إبراهيم","مصطفى","حسن","فؤاد","سامي","كامل","رأفت","السيد","الشناوي","الششتاوي","الجزار","عبدالعزيز","العشري","الفقي","مرسي","سليمان","الألفي"]

# ─── العناوين ───
GOVERNORATES = [
    ("القاهرة", ["المعادي","مدينة نصر","مصر الجديدة","حلوان","شبرا","الزمالك","وسط البلد","المرج","عين شمس","العباسية"]),
    ("الجيزة", ["الدقي","المهندسين","فيصل","الهرم","6 أكتوبر","الشيخ زايد","إمبابة","البدرشين"]),
    ("الإسكندرية", ["سيدي جابر","العجمي","المنتزه","محرم بك","العطارين","كرموز"]),
    ("المنصورة", ["المشاية","الجلاء","توريل","المنصورة الجديدة"]),
    ("طنطا", ["سعيد","البحري","الجمهورية","المحطة"]),
    ("الزقازيق", ["القومية","المدينة الجامعية","شيبة"]),
    ("أسيوط", ["الوليدية","الأزهر","سيد","الزهراء"]),
    ("أسوان", ["السد العالي","النصر","الشيخ هارون"]),
]

STREETS = ["شارع 9","شارع الجمهورية","شارع الثورة","شارع الهرم","شارع النصر","شارع 6 أكتوبر","شارع المدارس","شارع المحطة","شارع الترعة","شارع الجيش","شارع سعد زغلول","شارع رمسيس"]

JOBS = ["مهندس برمجيات","طبيب أسنان","محاسب","مدرّس","صيدلي","ممرض","تاجر","صاحب مطعم","مبرمج","محامي","صحفي","مهندس مدني","مصمم جرافيك","سائق","موظف بنك","شرطي","ضابط","طالب","صاحب شركة","مقاول"]

MARITAL = ["أعزب","متزوج","متزوج ويعول","مطلق","أرمل"]

# ─── إيميل ───
EMAIL_DOMAINS = ["gmail.com","yahoo.com","outlook.com","hotmail.com","icloud.com","protonmail.com"]


# ═══════════════════════════════════════════════════════════
# 💾 IO
# ═══════════════════════════════════════════════════════════

def _load(p, d):
    if not os.path.exists(p): return d
    try:
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    except: return d


def _save(p, data):
    try:
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[data] save {p}: {e}")


# ═══════════════════════════════════════════════════════════
# 🔌 ATTACH
# ═══════════════════════════════════════════════════════════

_DATA_BOT = None

def data_attach_bot(bot):
    global _DATA_BOT
    _DATA_BOT = bot
    print("✅ [DATA] Bot attached")


def data_init():
    os.makedirs(DATA_DIR, exist_ok=True)
    print("✅ [DATA] Ready (fake Egyptian data mode)")


# ═══════════════════════════════════════════════════════════
# 👤 Users + Points
# ═══════════════════════════════════════════════════════════

def _users(): return _load(DATA_USERS, {})
def _save_users(d): _save(DATA_USERS, d)


def data_ensure_user(uid: int, referrer: Optional[int] = None) -> Dict:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {
            "points": STARTING_POINTS, "referrer": None,
            "invited_count": 0, "total_lookups": 0,
            "created_at": datetime.now().isoformat(),
        }
        if referrer and referrer != uid:
            rk = str(referrer)
            if rk in data:
                data[k]["referrer"] = referrer
                data[rk]["invited_count"] = data[rk].get("invited_count", 0) + 1
                data[rk]["points"] = data[rk].get("points", 0) + REFERRAL_REWARD
        _save_users(data)
    return data[k]


def data_get_points(uid: int) -> int:
    return data_ensure_user(uid).get("points", 0)


def data_get_info(uid: int) -> Dict:
    return data_ensure_user(uid)


def data_add_points(uid: int, amount: int) -> int:
    if amount <= 0: return data_get_points(uid)
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_lookups": 0}
    data[k]["points"] = data[k].get("points", 0) + amount
    _save_users(data)
    return data[k]["points"]


def data_sub_points(uid: int, amount: int) -> bool:
    if amount <= 0: return True
    data = _users(); k = str(uid)
    if k not in data: return False
    if data[k].get("points", 0) < amount: return False
    data[k]["points"] -= amount
    _save_users(data)
    return True


def data_set_points(uid: int, amount: int) -> int:
    data = _users(); k = str(uid)
    if k not in data:
        data[k] = {"points": 0, "referrer": None, "invited_count": 0, "total_lookups": 0}
    data[k]["points"] = max(0, int(amount))
    _save_users(data)
    return data[k]["points"]


def data_inc_lookups(uid: int):
    data = _users(); k = str(uid)
    if k in data:
        data[k]["total_lookups"] = data[k].get("total_lookups", 0) + 1
        _save_users(data)


def data_get_all_users() -> Dict:
    return _users()


def data_get_referral_link(uid: int, bot_username: str) -> str:
    return f"https://t.me/{bot_username.lstrip('@')}?start=data_ref_{uid}"


def data_parse_referral(text: str) -> Optional[int]:
    if not text: return None
    parts = text.strip().split()
    if len(parts) < 2: return None
    if parts[1].startswith("data_ref_"):
        try: return int(parts[1].replace("data_ref_", ""))
        except: return None
    return None


# ─── الأكواد ───
def _codes(): return _load(DATA_CODES, {})
def _save_codes(d): _save(DATA_CODES, d)


def data_create_code(points: int, max_uses: int, created_by: int = 0) -> str:
    codes = _codes()
    while True:
        code = "DATA-" + ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
        if code not in codes: break
    codes[code] = {"points": points, "max_uses": max_uses, "uses": 0,
                   "created_by": created_by, "created_at": datetime.now().isoformat()}
    _save_codes(codes)
    return code


def data_redeem_code(code: str, uid: int) -> Dict:
    code = code.strip().upper()
    codes = _codes()
    if code not in codes: return {"success": False, "error": "❌ كود غير صالح"}
    c = codes[code]
    if c["uses"] >= c["max_uses"]: return {"success": False, "error": "❌ الكود انتهى"}
    c["uses"] += 1
    _save_codes(codes)
    new_bal = data_add_points(uid, c["points"])
    return {"success": True, "points_added": c["points"], "new_balance": new_bal}


def data_list_codes() -> Dict:
    return _codes()


# ═══════════════════════════════════════════════════════════
# 🇪🇬 توليد البيانات الوهمية
# ═══════════════════════════════════════════════════════════

def _gen_arabic_name() -> str:
    """اسم رباعي مصري"""
    return f"{random.choice(FIRST_NAMES)} {random.choice(MIDDLE_NAMES)} {random.choice(MIDDLE_NAMES)} {random.choice(FAMILY_NAMES)}"


def _gen_english_name(arabic_name: str) -> str:
    """الاسم بالإنجليزي"""
    trans = {
        "أحمد":"Ahmed","محمد":"Mohamed","محمود":"Mahmoud","مصطفى":"Mostafa","عمر":"Omar",
        "يوسف":"Youssef","علي":"Ali","حسن":"Hassan","إبراهيم":"Ibrahim","خالد":"Khaled",
        "أيمن":"Ayman","عمرو":"Amr","طارق":"Tarek","هشام":"Hesham","كريم":"Karim",
        "سامح":"Sameh","شريف":"Sherif","ياسر":"Yasser","وائل":"Wael","أشرف":"Ashraf",
        "إسلام":"Islam","رضا":"Reda","ماجد":"Maged","هاني":"Hany",
        "حسين":"Hussein","سعيد":"Saeed","عبدالله":"Abdullah","عبدالرحمن":"Abdulrahman",
        "فتحي":"Fathy","كمال":"Kamal","فؤاد":"Fouad","سامي":"Samy","كامل":"Kamel",
        "رأفت":"Raafat","السيد":"Elsayed","الشناوي":"Elshennawy","الششتاوي":"Elsheshtawy",
        "الجزار":"Elgazzar","عبدالعزيز":"Abdelaziz","العشري":"Elashry","الفقي":"Elfiky",
        "مرسي":"Morsi","سليمان":"Soliman","الألفي":"Elalfy",
    }
    parts = arabic_name.split()
    return " ".join(trans.get(p, p) for p in parts)


def _gen_address() -> Dict:
    """عنوان مصري تفصيلي"""
    gov, areas = random.choice(GOVERNORATES)
    area = random.choice(areas)
    street = random.choice(STREETS)
    building = random.randint(1, 200)
    floor = random.randint(1, 15)
    apartment = random.randint(1, 30)
    landmark = random.choice([
        "بجوار مسجد", "أمام صيدلية", "خلف مدرسة", "بجوار سوبر ماركت",
        "أمام بنك", "بجوار محطة مترو", "خلف مستشفى",
    ])
    return {
        "governorate": gov,
        "area": area,
        "street": street,
        "building": building,
        "floor": floor,
        "apartment": apartment,
        "landmark": landmark,
        "full": f"{gov} - {area} - {street} - عمارة {building} - الدور {floor} - شقة {apartment} - {landmark}",
    }


def _gen_national_id() -> Dict:
    """رقم قومي 14 رقم يبدأ بـ 2 أو 3"""
    century = random.choice(["2", "3"])
    
    # ─── السنة (حسب القرن) ───
    if century == "2":
        year = random.randint(50, 99)  # 1950-1999
    else:
        year = random.randint(0, 25)   # 2000-2025
    
    year_str = f"{year:02d}"
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    
    # ─── المحافظة (01-35) ───
    gov_code = f"{random.randint(1, 35):02d}"
    
    # ─── تسلسل + جنس (فردي=ذكر، زوجي=أنثى) ───
    serial = f"{random.randint(1, 9999):04d}"
    
    # ─── رقم التحقق ───
    check = str(random.randint(0, 9))
    
    nid = f"{century}{year_str}{month:02d}{day:02d}{gov_code}{serial}{check}"
    
    # ─── كشف التاريخ ───
    try:
        century_full = 1900 if century == "2" else 2000
        birth = datetime(century_full + year, month, day)
        birth_str = birth.strftime("%d/%m/%Y")
        today = datetime.now()
        age = today.year - birth.year
        if (today.month, today.day) < (month, day): age -= 1
    except:
        birth_str = "?"
        age = "?"
    
    gender_digit = int(serial[-1])
    gender = "ذكر" if gender_digit % 2 == 1 else "أنثى"
    
    return {
        "number": nid,
        "birth": birth_str,
        "age": age,
        "gender": gender,
        "governorate_code": gov_code,
    }


def _gen_email(eng_name: str) -> str:
    """إيميل من الاسم الإنجليزي"""
    parts = re.sub(r'[^a-zA-Z\s]', '', eng_name).lower().split()
    if len(parts) >= 2:
        base = f"{parts[0]}.{parts[-1]}"
    else:
        base = parts[0] if parts else "user"
    
    num = random.randint(1, 9999)
    domain = random.choice(EMAIL_DOMAINS)
    return f"{base}{num}@{domain}"


def _gen_secondary_phone() -> str:
    """رقم تاني عشوائي"""
    prefix = random.choice(["010", "011", "012", "015"])
    body = ''.join(str(random.randint(0, 9)) for _ in range(7))
    return f"+20{prefix[1:]}{body}"


def _gen_full_data(phone: str) -> Dict:
    """يولّد كل البيانات الوهمية"""
    arabic_name = _gen_arabic_name()
    eng_name = _gen_english_name(arabic_name)
    address = _gen_address()
    nid = _gen_national_id()
    email = _gen_email(eng_name)
    job = random.choice(JOBS)
    marital = random.choice(MARITAL)
    secondary_phone = _gen_secondary_phone()
    
    return {
        "phone": phone,
        "name": arabic_name,
        "name_en": eng_name,
        "address": address,
        "national_id": nid,
        "email": email,
        "job": job,
        "marital": marital,
        "secondary_phone": secondary_phone,
        "carrier": random.choice(["Vodafone","Etisalat","Orange","WE"]),
    }


async def data_lookup_phone(phone: str) -> Dict:
    """البحث عن رقم — بيانات وهمية"""
    await asyncio.sleep(random.uniform(1.5, 2.5))
    
    phone_clean = re.sub(r'[^\d+]', '', phone)
    if not phone_clean.startswith("+"):
        phone_clean = "+" + phone_clean
    
    return {
        "success": True,
        "phone": phone_clean,
        "data": _gen_full_data(phone_clean),
        "timestamp": datetime.now().isoformat(),
    }


# ═══════════════════════════════════════════════════════════
# 🎯 ROUTER — كل معالجات الأزرار
# ═══════════════════════════════════════════════════════════

DATA_STATES: Dict[int, dict] = {}

def _st(uid): return DATA_STATES.setdefault(uid, {})
def _reset(uid): DATA_STATES[uid] = {}


async def data_callback_router(event, uid: int, data: str):
    """Router قسم Data"""
    # ─── استخراج sub ───
    if data == "data:home" or data == "dmenu:home":
        await _show_home(event, uid)
        return
    
    if data.startswith("data:"):
        sub = data.replace("data:", "")
    elif data.startswith("dmenu:"):
        sub = data.replace("dmenu:", "")
    else:
        sub = data
    
    is_admin_user = uid in ADMIN_IDS if 'ADMIN_IDS' in globals() else uid == DATA_DEVELOPER_ID
    
    # ═══ استبدال كود ═══
    if sub == "redeem":
        _reset(uid); _st(uid)["flow"] = "wait_code"
        try:
            await event.edit(
                "🎫 <b>استبدال كود</b>\n\n📥 ابعت الكود:",
                buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ نقاطي ═══
    if sub == "points":
        pts = data_get_points(uid)
        info = data_get_info(uid)
        try:
            await event.edit(
                f"💰 <b>نقاطي</b>\n\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                f"⭐ <b>الرصيد:</b> <code>{pts}</code>\n"
                f"👥 <b>الإحالات:</b> <code>{info.get('invited_count',0)}</code>\n"
                f"📊 <b>عمليات البحث:</b> <code>{info.get('total_lookups',0)}</code>\n"
                f"━━━━━━━━━━━━━━━━━━━━━━━",
                buttons=[
                    [Button.inline("🔗 الإحالة", b"data:referral")],
                    [Button.inline("🎫 كود", b"data:redeem")],
                    [Button.inline("↩️ رجوع", b"data:home")],
                ],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ الإحالة ═══
    if sub == "referral":
        try:
            me = await _DATA_BOT.get_me()
            link = data_get_referral_link(uid, me.username or "")
            info = data_get_info(uid)
            await event.edit(
                f"🔗 <b>رابط الإحالة</b>\n\n"
                f"<code>{link}</code>\n\n"
                f"👥 <b>إحالاتك:</b> <code>{info.get('invited_count',0)}</code>\n\n"
                f"🎁 <b>كل واحد يدخل من الرابط:</b>\n"
                f"   ⭐ <b>+1 نقطة لك</b>\n"
                f"   ⭐ <b>+3 نقاط له</b>",
                buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                parse_mode="html",
            )
        except Exception as e:
            await event.answer(f"❌ {str(e)[:50]}", alert=True)
        return
    
    # ═══ بدء البحث ═══
    if sub == "start":
        if not is_admin_user:
            if data_get_points(uid) < LOOKUP_COST:
                await event.answer(
                    "❌ نقاطك مش كافية!\n🔗 شارك رابط الإحالة",
                    alert=True
                )
                return
        _reset(uid); _st(uid)["flow"] = "wait_phone"
        try:
            await event.edit(
                "📱 <b>ابعت رقم التليفون:</b>\n\n"
                "💡 أمثلة:\n"
                "   • <code>+201012345678</code>\n"
                "   • <code>01012345678</code>\n\n"
                f"💰 <b>التكلفة:</b> <code>{LOOKUP_COST} نقطة</code>",
                buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                parse_mode="html",
            )
        except: pass
        return
    
    # ═══ أوامر الأدمن ═══
    if sub.startswith("adm:"):
        if not is_admin_user:
            await event.answer("⛔ أدمن فقط!", alert=True)
            return
        action = sub.replace("adm:", "")
        
        if action == "code":
            _reset(uid); _st(uid)["flow"] = "admin_code"
            try:
                await event.edit(
                    "🎫 <b>إنشاء كود</b>\n\n"
                    "📝 ابعت: <code>النقاط : عدد الاستخدامات</code>\n"
                    "💡 مثال: <code>5 : 10</code>",
                    buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                    parse_mode="html",
                )
            except: pass
            return
        
        if action == "add":
            _reset(uid); _st(uid)["flow"] = "admin_add"
            try:
                await event.edit(
                    "➕ <b>إضافة نقاط</b>\n\n"
                    "📝 ابعت: <code>الآيدي : النقاط</code>",
                    buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                    parse_mode="html",
                )
            except: pass
            return
        
        if action == "stats":
            users = data_get_all_users()
            tp = sum(u.get("points", 0) for u in users.values())
            tl = sum(u.get("total_lookups", 0) for u in users.values())
            try:
                await event.edit(
                    f"📊 <b>إحصائيات Data</b>\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"👥 <b>المستخدمين:</b> <code>{len(users)}</code>\n"
                    f"⭐ <b>إجمالي النقاط:</b> <code>{tp}</code>\n"
                    f"📊 <b>عمليات البحث:</b> <code>{tl}</code>\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━",
                    buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                    parse_mode="html",
                )
            except: pass
            return
    
    # ═══ غير معروف ═══
    await event.answer("خيار غير معروف", alert=True)


async def _show_home(event, uid: int):
    """الصفحة الرئيسية"""
    _reset(uid)
    is_admin_user = uid in ADMIN_IDS if 'ADMIN_IDS' in globals() else uid == DATA_DEVELOPER_ID
    pts = data_get_points(uid)
    info = data_get_info(uid)
    
    buttons = [
        [Button.inline("🔍 ابدأ البحث", b"data:start")],
        [Button.inline("💰 نقاطي", b"data:points"),
         Button.inline("🔗 الإحالة", b"data:referral")],
        [Button.inline("🎫 استبدال كود", b"data:redeem")],
    ]
    if is_admin_user:
        buttons.append([
            Button.inline("📊 إحصائيات", b"data:adm:stats"),
            Button.inline("🎫 صنع كود", b"data:adm:code"),
        ])
        buttons.append([Button.inline("➕ إضافة نقاط", b"data:adm:add")])
    buttons.append([Button.inline("↩️ رجوع", b"menu:home")])
    
    try:
        await event.edit(
            "📊━━━━━━━━━━━━━━━━━━━━━━━━📊\n"
            "     <b>𝗗𝗔𝗧𝗔 𝗮.𝗘𝗫𝗧𝗥𝗔𝗖𝗧</b>\n"
            "📊━━━━━━━━━━━━━━━━━━━━━━━━📊\n\n"
            "🔍 <b>سحب بيانات من رقم</b>\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"💰 <b>نقاطك:</b> <code>{pts}</code>\n"
            f"👥 <b>إحالاتك:</b> <code>{info.get('invited_count',0)}</code>\n"
            f"📊 <b>عمليات البحث:</b> <code>{info.get('total_lookups',0)}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            "📋 <b>البيانات:</b>\n"
            "   • 👤 اسم رباعي\n"
            "   • 🏠 عنوان تفصيلي\n"
            "   • 🔢 رقم قومي\n"
            "   • 💼 وظيفة + حالة اجتماعية\n"
            "   • 📧 إيميل + رقم تاني",
            buttons=buttons,
            parse_mode="html",
        )
    except: pass


# ═══════════════════════════════════════════════════════════
# ✍️ Text Handler
# ═══════════════════════════════════════════════════════════

async def data_text_handler(event, uid: int, text: str) -> bool:
    st = _st(uid)
    flow = st.get("flow")
    is_admin_user = uid in ADMIN_IDS if 'ADMIN_IDS' in globals() else uid == DATA_DEVELOPER_ID
    
    if not flow: return False
    
    # ═══ بحث ═══
    if flow == "wait_phone":
        phone = text.strip()
        digits = re.sub(r'\D', '', phone)
        if len(digits) < 8:
            await event.respond("❌ رقم غير صحيح")
            return True
        
        if not is_admin_user:
            if not data_sub_points(uid, LOOKUP_COST):
                await event.respond(
                    f"❌ <b>نقاطك مش كافية!</b>\n💰 رصيدك: <code>{data_get_points(uid)}</code>",
                    parse_mode="html",
                    buttons=[[Button.inline("🔗 الإحالة", b"data:referral")],
                             [Button.inline("🎫 كود", b"data:redeem")]],
                )
                _reset(uid); return True
        
        msg = await event.respond("⏳ <b>جاري البحث...</b>", parse_mode="html")
        
        try:
            result = await data_lookup_phone(phone)
            if result.get("success"):
                data_inc_lookups(uid)
                new_bal = data_get_points(uid)
                d = result["data"]
                
                if is_admin_user:
                    balance_line = "👑 <b>أدمن — مجاني</b>"
                else:
                    balance_line = f"⭐ <b>رصيدك:</b> <code>{new_bal}</code>"
                
                output = (
                    f"✅━━━━━━━━━━━━━━━━━━━━━━━━✅\n"
                    f"     <b>𝗗𝗮𝘁𝗮 𝗙𝗼𝘂𝗻𝗱</b>\n"
                    f"✅━━━━━━━━━━━━━━━━━━━━━━━━✅\n\n"
                    f"📱 <b>الرقم:</b>\n<code>{result['phone']}</code>\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"👤 <b>الاسم:</b>\n{d['name']}\n"
                    f"📝 <b>EN:</b> {d['name_en']}\n\n"
                    f"🏠 <b>العنوان:</b>\n{d['address']['full']}\n\n"
                    f"🔢 <b>الرقم القومي:</b>\n<code>{d['national_id']['number']}</code>\n"
                    f"📅 <b>الميلاد:</b> {d['national_id']['birth']}\n"
                    f"🎂 <b>العمر:</b> {d['national_id']['age']} سنة\n"
                    f"👤 <b>الجنس:</b> {d['national_id']['gender']}\n\n"
                    f"💼 <b>الوظيفة:</b> {d['job']}\n"
                    f"💍 <b>الحالة:</b> {d['marital']}\n"
                    f"📧 <b>الإيميل:</b>\n<code>{d['email']}</code>\n"
                    f"📱 <b>رقم تاني:</b>\n<code>{d['secondary_phone']}</code>\n\n"
                    f"━━━━━━━━━━━━━━━━━━━━━━━\n"
                    f"{balance_line}\n"
                    f"🦊 <b>FOX DATA</b>"
                )
                
                await msg.edit(
                    output[:4000],
                    buttons=[
                        [Button.inline("🔍 بحث تاني", b"data:start")],
                        [Button.inline("💰 نقاطي", b"data:points")],
                        [Button.inline("↩️ رجوع", b"data:home")],
                    ],
                    parse_mode="html",
                )
            else:
                if not is_admin_user:
                    data_add_points(uid, LOOKUP_COST)
                await msg.edit(
                    f"❌ <b>فشل البحث</b>\n\n✅ <i>تم استرجاع النقطة</i>",
                    buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                    parse_mode="html",
                )
        except Exception as e:
            if not is_admin_user:
                data_add_points(uid, LOOKUP_COST)
            await msg.edit(f"❌ <b>خطأ:</b>\n<code>{str(e)[:200]}</code>",
                           parse_mode="html")
        
        _reset(uid); return True
    
    # ═══ استبدال كود ═══
    if flow == "wait_code":
        code = text.strip().upper()
        result = data_redeem_code(code, uid)
        _reset(uid)
        if result.get("success"):
            await event.respond(
                f"✅ <b>تم استبدال الكود!</b>\n\n"
                f"🎫 <code>{code}</code>\n"
                f"⭐ <b>+{result['points_added']}</b>\n"
                f"💰 <b>رصيدك:</b> <code>{result['new_balance']}</code>",
                buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
                parse_mode="html",
            )
        else:
            await event.respond(result.get("error", "❌ خطأ"),
                                buttons=[[Button.inline("↩️ رجوع", b"data:home")]])
        return True
    
    # ═══ أدمن — كود ═══
    if flow == "admin_code":
        if not is_admin_user:
            _reset(uid); return True
        try:
            parts = text.split(":")
            if len(parts) != 2: raise ValueError
            pts = int(parts[0].strip()); uses = int(parts[1].strip())
            if pts <= 0 or uses <= 0: raise ValueError
        except:
            await event.respond("❌ صيغة: `5 : 10`", parse_mode="html")
            return True
        code = data_create_code(pts, uses, uid)
        _reset(uid)
        await event.respond(
            f"✅ <b>تم إنشاء الكود!</b>\n\n"
            f"🎫 <code>{code}</code>\n"
            f"⭐ <code>{pts}</code> | 📊 <code>{uses}</code>",
            buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
            parse_mode="html",
        )
        return True
    
    # ═══ أدمن — إضافة نقاط ═══
    if flow == "admin_add":
        if not is_admin_user:
            _reset(uid); return True
        try:
            parts = text.split(":")
            if len(parts) != 2: raise ValueError
            tid = int(parts[0].strip()); pts = int(parts[1].strip())
        except:
            await event.respond("❌ صيغة: `123456 : 50`", parse_mode="html")
            return True
        new_bal = data_add_points(tid, pts)
        _reset(uid)
        await event.respond(
            f"✅ <b>تم!</b>\n👤 <code>{tid}</code>\n⭐ <code>+{pts}</code>\n💰 <code>{new_bal}</code>",
            buttons=[[Button.inline("↩️ رجوع", b"data:home")]],
            parse_mode="html",
        )
        return True
    
    return False


async def data_media_handler(event, uid: int) -> bool:
    return False